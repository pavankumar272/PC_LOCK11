import sys
from PySide6.QtWidgets import QApplication
from smartlock.app import SmartLockWindow

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AI Smart PC Lock")
    app.setOrganizationName("SmartLock")
    window = SmartLockWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
