# AI Smart PC Lock (Windows 11)

A local Windows desktop utility that monitors webcam face presence and locks the workstation after the configured absence timeout. Optional head-turn detection is a simple face-landmark heuristic, not identity recognition.

## Features
- MediaPipe Face Mesh detection using the local webcam.
- Default 10-second absence timeout.
- Optional head-turn-away heuristic.
- Windows `LockWorkStation` integration.
- System tray dashboard; closing the window minimizes to tray.
- Activity log at `%APPDATA%\\AISmartPCLock\\activity.log`.
- Optional per-user Windows startup entry (`HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run`).
- No image/video recording and no cloud upload.

## Requirements
- Windows 11, 64-bit.
- Python 3.11 (recommended) installed and added to PATH.
- Webcam and Windows camera permission.
- Internet only for installing Python packages; runtime processing is local.

## Install and run from source
1. Install 64-bit Python 3.11.
2. Extract this project to a folder such as `C:\\AI-Smart-PC-Lock`.
3. Open Command Prompt in that folder.
4. Create and activate a virtual environment:
   ```bat
   py -3.11 -m venv .venv
   .venv\\Scripts\\activate
   ```
5. Install dependencies:
   ```bat
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
6. Start:
   ```bat
   python main.py
   ```

On first launch, startup is enabled by default. The app registers itself to run at the next Windows sign-in and automatically starts webcam monitoring shortly after launch. The source-run startup command points to the same `main.py`, so do not move the extracted folder after enabling startup. To disable it, uncheck the startup option and click Save settings.

## Build a standalone EXE
Run from the activated virtual environment:
```bat
pip install pyinstaller
pyinstaller --noconfirm --windowed --name "AI Smart PC Lock" --collect-all mediapipe --collect-all cv2 main.py
```
The executable will be under `dist\\AI Smart PC Lock\\AI Smart PC Lock.exe` (or `dist\\AI Smart PC Lock.exe`, depending on PyInstaller version). For reliable startup registration, run the EXE from its final permanent location. Copy the complete `dist` output folder to that location before enabling startup.

## How it behaves
- A face being detected resets the absence timer.
- If no face is detected continuously for 10 seconds, Windows is locked.
- If head-turn detection is enabled, a face turned significantly sideways may count as away. The threshold is a heuristic and may need tuning for your camera, lighting, and face position.
- If the camera cannot open, the app reports an error and does not lock the PC.
- After a lock is triggered, the app does not repeatedly issue lock commands while the user remains away.

## Testing checklist
1. Launch the app and confirm the camera LED/preview activity indicates camera access.
2. Start monitoring with your face in view; status should show `Present`.
3. Move out of frame; status should show `Away` and countdown.
4. Return within 10 seconds; timer should reset and no lock should occur.
5. Leave the frame for more than 10 seconds; Windows should lock.
6. Unlock Windows and check the activity log.
7. Test head-turn behavior by turning your head sideways; adjust or disable it if it produces false positives.
8. Save startup enabled, sign out and sign back in; verify the app starts. Disable startup and verify it no longer starts at sign-in.
9. Test Stop and Exit from the tray menu.

## Safety and limitations
- Test the timeout at 30–60 seconds initially if you are concerned about accidental locking; change back to 10 seconds afterward.
- Keep Windows Hello/PIN/password configured. This app only locks Windows; it does not implement authentication or unlock the PC.
- Face detection is not face recognition. Any visible face may keep the PC unlocked.
- The head-turn feature is approximate and can be affected by camera angle, lighting, glasses, and individual facial geometry.
- Avoid using this as the sole security control for sensitive environments.
- If you use a laptop with a privacy shutter or camera permission disabled, monitoring cannot work.
