import cv2
import mediapipe as mp

class PresenceDetector:
    """
    FaceMesh-based local detector. No frames are saved or transmitted.
    `present` means a face is visible and, when enabled, not turned away.
    Yaw is approximated from the relative horizontal positions of nose and eye corners.
    """
    def __init__(self, head_turn_enabled=True, head_turn_threshold=0.18):
        self.head_turn_enabled = head_turn_enabled
        self.head_turn_threshold = float(head_turn_threshold)
        self.mesh = mp.solutions.face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.55,
            min_tracking_confidence=0.55
        )

    def detect(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = self.mesh.process(rgb)
        if not result.multi_face_landmarks:
            return False, "No face detected"
        if not self.head_turn_enabled:
            return True, "Face detected"
        points = result.multi_face_landmarks[0].landmark
        # FaceMesh: nose tip 1, outer eye corners 33 and 263.
        nose_x = points[1].x
        left_eye_x = points[33].x
        right_eye_x = points[263].x
        eye_mid = (left_eye_x + right_eye_x) / 2.0
        eye_width = max(abs(right_eye_x - left_eye_x), 0.001)
        yaw_ratio = abs(nose_x - eye_mid) / eye_width
        if yaw_ratio > self.head_turn_threshold:
            return False, "Head turned away"
        return True, "Face detected"

    def close(self):
        self.mesh.close()
