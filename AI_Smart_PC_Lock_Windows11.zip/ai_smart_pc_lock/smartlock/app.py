import os
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSpinBox, QCheckBox, QSystemTrayIcon, QMenu, QMessageBox, QGroupBox
)
from .config import load_config, save_config, LOG_PATH
from .logger import logger
from .monitor import CameraMonitor
from .windows import set_startup, startup_is_enabled

class SmartLockWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AI Smart PC Lock")
        self.setMinimumSize(440, 360)
        self.config = load_config()
        self.monitor = None
        self._build_ui()
        self._build_tray()
        if os.name == "nt" and self.config.get("start_with_windows", True):
            try:
                set_startup(True)
            except Exception as exc:
                logger.exception("Could not configure startup")
                self.status.setText(f"Startup setup failed: {exc}")
            # When launched at Windows sign-in, begin presence monitoring automatically.
            QTimer.singleShot(1500, self.start_monitoring)

    def _build_ui(self):
        root = QWidget()
        layout = QVBoxLayout(root)
        title = QLabel("AI Smart PC Lock")
        title.setStyleSheet("font-size: 22px; font-weight: 700;")
        subtitle = QLabel("Local webcam presence monitoring for Windows 11")
        self.status = QLabel("Status: Not monitoring")
        self.detail = QLabel("Start monitoring to activate automatic locking.")
        self.detail.setWordWrap(True)
        group = QGroupBox("Settings")
        form = QVBoxLayout(group)
        row = QHBoxLayout()
        row.addWidget(QLabel("Lock after face is missing (seconds):"))
        self.timeout = QSpinBox()
        self.timeout.setRange(5, 300)
        self.timeout.setValue(int(self.config["lock_timeout_seconds"]))
        row.addWidget(self.timeout)
        form.addLayout(row)
        self.head_turn = QCheckBox("Treat a strongly turned-away head as away")
        self.head_turn.setChecked(bool(self.config["head_turn_enabled"]))
        form.addWidget(self.head_turn)
        self.startup = QCheckBox("Start automatically when I sign in to Windows")
        self.startup.setChecked(bool(self.config["start_with_windows"]))
        form.addWidget(self.startup)
        buttons = QHBoxLayout()
        self.start_btn = QPushButton("Start monitoring")
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setEnabled(False)
        self.start_btn.clicked.connect(self.start_monitoring)
        self.stop_btn.clicked.connect(self.stop_monitoring)
        buttons.addWidget(self.start_btn)
        buttons.addWidget(self.stop_btn)
        save_btn = QPushButton("Save settings")
        save_btn.clicked.connect(self.save_settings)
        log_btn = QPushButton("Open activity log")
        log_btn.clicked.connect(self.open_log)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(12)
        layout.addWidget(self.status)
        layout.addWidget(self.detail)
        layout.addWidget(group)
        layout.addLayout(buttons)
        layout.addWidget(save_btn)
        layout.addWidget(log_btn)
        layout.addStretch()
        privacy = QLabel("Privacy: frames are processed locally and are not recorded.")
        privacy.setStyleSheet("color: gray;")
        layout.addWidget(privacy)
        self.setCentralWidget(root)

    def _build_tray(self):
        self.tray = QSystemTrayIcon(self)
        self.tray.setToolTip("AI Smart PC Lock")
        menu = QMenu()
        show_action = QAction("Open dashboard", self)
        show_action.triggered.connect(self.showNormal)
        start_action = QAction("Start monitoring", self)
        start_action.triggered.connect(self.start_monitoring)
        stop_action = QAction("Stop monitoring", self)
        stop_action.triggered.connect(self.stop_monitoring)
        quit_action = QAction("Exit", self)
        quit_action.triggered.connect(self.quit_app)
        menu.addAction(show_action)
        menu.addAction(start_action)
        menu.addAction(stop_action)
        menu.addSeparator()
        menu.addAction(quit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()

    def _tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.showNormal()
            self.activateWindow()

    def save_settings(self):
        self.config["lock_timeout_seconds"] = self.timeout.value()
        self.config["head_turn_enabled"] = self.head_turn.isChecked()
        self.config["start_with_windows"] = self.startup.isChecked()
        save_config(self.config)
        try:
            set_startup(self.startup.isChecked())
            self.status.setText("Status: Settings saved")
        except Exception as exc:
            QMessageBox.warning(self, "Startup setting", str(exc))
        logger.info("Settings saved")

    def start_monitoring(self):
        if self.monitor and self.monitor.isRunning():
            return
        self.save_settings()
        self.monitor = CameraMonitor(
            timeout_seconds=self.timeout.value(),
            camera_index=self.config["camera_index"],
            head_turn_enabled=self.head_turn.isChecked(),
            head_turn_threshold=self.config["head_turn_threshold"]
        )
        self.monitor.status_changed.connect(self.update_status)
        self.monitor.error.connect(self.show_error)
        self.monitor.locked.connect(lambda: self.tray.showMessage("AI Smart PC Lock", "Windows workstation locked."))
        self.monitor.start()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        logger.info("Monitoring requested")

    def stop_monitoring(self):
        if self.monitor and self.monitor.isRunning():
            self.monitor.stop()
            self.monitor.wait(3000)
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.status.setText("Status: Stopped")
        self.detail.setText("Monitoring is off.")

    def update_status(self, state, detail):
        self.status.setText(f"Status: {state}")
        self.detail.setText(detail)
        if state in ("Away", "Locking"):
            self.tray.setToolTip(f"AI Smart PC Lock — {state}")
        else:
            self.tray.setToolTip("AI Smart PC Lock")

    def show_error(self, message):
        logger.error(message)
        self.status.setText("Status: Error")
        self.detail.setText(message)
        if self.isVisible():
            QMessageBox.warning(self, "AI Smart PC Lock", message)

    def open_log(self):
        os.startfile(str(LOG_PATH))

    def closeEvent(self, event):
        # Closing the window minimizes to tray; Exit is available from tray menu.
        event.ignore()
        self.hide()
        if self.tray.isVisible():
            self.tray.showMessage("AI Smart PC Lock", "Still running in the system tray.")

    def quit_app(self):
        self.stop_monitoring()
        self.tray.hide()
        self.closeEvent = lambda event: event.accept()
        self.close()
