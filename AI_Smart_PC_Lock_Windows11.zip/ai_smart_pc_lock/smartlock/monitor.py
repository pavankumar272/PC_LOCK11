import time
import cv2
from PySide6.QtCore import QThread, Signal
from .detector import PresenceDetector
from .logger import logger
from .windows import lock_workstation

class CameraMonitor(QThread):
    status_changed = Signal(str, str)
    error = Signal(str)
    locked = Signal()

    def __init__(self, timeout_seconds=10, camera_index=0, head_turn_enabled=True, head_turn_threshold=0.18):
        super().__init__()
        self.timeout_seconds = int(timeout_seconds)
        self.camera_index = int(camera_index)
        self.head_turn_enabled = bool(head_turn_enabled)
        self.head_turn_threshold = float(head_turn_threshold)
        self._running = True
        self._last_seen = time.monotonic()
        self._lock_sent = False

    def stop(self):
        self._running = False

    def run(self):
        cap = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW)
        if not cap.isOpened():
            cap.release()
            self.error.emit("Cannot open webcam. Check camera permission and camera index.")
            return
        detector = None
        try:
            detector = PresenceDetector(self.head_turn_enabled, self.head_turn_threshold)
            self.status_changed.emit("Monitoring", "Camera active — waiting for face")
            logger.info("Camera monitoring started")
            while self._running:
                ok, frame = cap.read()
                if not ok:
                    self.status_changed.emit("Camera error", "Unable to read camera frame")
                    time.sleep(0.5)
                    continue
                present, reason = detector.detect(frame)
                now = time.monotonic()
                if present:
                    self._last_seen = now
                    self._lock_sent = False
                    self.status_changed.emit("Present", reason)
                else:
                    missing = now - self._last_seen
                    remaining = max(0, self.timeout_seconds - int(missing))
                    self.status_changed.emit("Away", f"{reason} — locking in {remaining}s")
                    if missing >= self.timeout_seconds and not self._lock_sent:
                        self._lock_sent = True
                        logger.warning("User absent for %s seconds; locking workstation", self.timeout_seconds)
                        self.status_changed.emit("Locking", "User absent — locking Windows")
                        try:
                            lock_workstation()
                            self.locked.emit()
                        except Exception as exc:
                            self.error.emit(f"Could not lock Windows: {exc}")
                        # Avoid repeated lock attempts while the user remains absent.
                time.sleep(0.12)
        except Exception as exc:
            logger.exception("Monitor failed")
            self.error.emit(str(exc))
        finally:
            if detector:
                detector.close()
            cap.release()
            logger.info("Camera monitoring stopped")
            self.status_changed.emit("Stopped", "Monitoring stopped")
