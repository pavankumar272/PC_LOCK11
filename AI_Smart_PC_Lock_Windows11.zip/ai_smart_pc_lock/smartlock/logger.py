import logging
from logging.handlers import RotatingFileHandler
from .config import APP_DIR, LOG_PATH

def get_logger():
    APP_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("AISmartPCLock")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = RotatingFileHandler(LOG_PATH, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        logger.addHandler(handler)
    return logger

logger = get_logger()
