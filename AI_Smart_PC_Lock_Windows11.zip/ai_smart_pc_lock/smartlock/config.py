import json
import os
from pathlib import Path

APP_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "AISmartPCLock"
CONFIG_PATH = APP_DIR / "config.json"
LOG_PATH = APP_DIR / "activity.log"

DEFAULTS = {
    "lock_timeout_seconds": 10,
    "start_with_windows": True,
    "camera_index": 0,
    "head_turn_enabled": True,
    "head_turn_threshold": 0.18,
    "show_notifications": True
}

def load_config():
    APP_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_PATH.exists():
        save_config(DEFAULTS)
        return DEFAULTS.copy()
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        return {**DEFAULTS, **data}
    except Exception:
        return DEFAULTS.copy()

def save_config(data):
    APP_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
